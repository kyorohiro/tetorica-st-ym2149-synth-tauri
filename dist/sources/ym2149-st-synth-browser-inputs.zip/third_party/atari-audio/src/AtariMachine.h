//----------------------------------------------------------
//
//	AtariAudio 1.31
//	Small & accurate ATARI-ST audio emulation
//	by Arnaud Carré aka Leonard/Oxygene (@leonard_coder)
//
//----------------------------------------------------------
#pragma once
#include <stdint.h>
#include "ym2149c.h"
#include "Mk68901.h"
#include "SteDac.h"
#include "Blitter.h"
#include "external/Musashi/m68k.h"
#include "external/Musashi/m68kops.h"

static	const	uint32_t	kAtariMachineRamSize = 4*1024*1024;				// you can reduce this to 512KiB if needed for tiny platform such as ESP32
static const	uint32_t	kAtariMachineGemdosAllocSize = 1*1024*1024;

class AtariMachine
{
public:
	AtariMachine();
	~AtariMachine();

	enum ExitCode
	{
		kCrash = (1 << 0),
		kReset = (1 << 1),
	};

	bool		Startup(uint32_t hostReplayRate, bool predictibleYm2149State = false);
	bool		Upload(const void* src, uint32_t addr, uint32_t size);
	bool 		PlayerTick(uint32_t musicDriverCallAddr);
	bool		Jsr(uint32_t addr, uint32_t d0);
	int16_t		ComputeNextSample();
	uint32_t	ComputeCurrentVisualLevels() const;

	unsigned int	memRead8(unsigned int address);
	unsigned int	memRead16(unsigned int address);
	void			memWrite8(unsigned int address, unsigned int value);
	void			memWrite16(unsigned int address, unsigned int value);
	int				TrapInstructionCallback(int v);
	void			ResetCb(void);
	void 			IllegalCb(void);
	void 			MuteVoices(uint32_t muteMask);
	uint8_t GetYmRegister(unsigned reg) const { return m_ym2149.GetRegister(reg); }

private:
	static	const	uint32_t	RTE_INSTRUCTION_ADDR = 0x500;
	static	const	uint32_t	RESET_INSTRUCTION_ADDR = 0x502;

	// Peter Johnson used Xbios(32) (DoSound) for Arkanoid and Wizball!!
	void 		DoSoundTick();
	void		ConfigureReturnByRts();
	void		ConfigureReturnByRte();
	bool		JmpBinary(uint32_t pc, int timeOut50Hz);
	void		Gemdos(int func, uint32_t a7);
	void		XBios(int func, uint32_t a7);
	void		XbiosTimerSet(int ctrlPort, int dataPort, int enablePort, int bit, int mask, int ctrlValue, int dataValue);

	uint32_t m_doSndPtr;
	uint8_t m_doSndVal;
	uint8_t m_doSndDelay;
	uint8_t*	m_RAM;
	int			m_exitCode;
	uint32_t	m_nextGemdosMallocAd;
	uint32_t 	m_muteMask;
	Ym2149c		m_ym2149;
	Mk68901		m_mfp;
	SteDac		m_steDac;
	Blitter 	m_blitter;
	M68k m_cpu;
};
