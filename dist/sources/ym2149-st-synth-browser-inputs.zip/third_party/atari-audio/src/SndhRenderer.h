//----------------------------------------------------------
//
//	AtariAudio 1.31
//	Small & accurate ATARI-ST audio emulation
//	by Arnaud Carré aka Leonard/Oxygene (@leonard_coder)
//
//----------------------------------------------------------
#pragma once
#include <stdint.h>
#include "AtariAudioRenderer.h"
#include "AtariMachine.h"

class SndhRenderer : public AtariAudioRenderer
{
public:
	// Read the base AtariAudioRenderer.h header for more details about API
	static SndhRenderer* Create(const void* sndhMemoryData, uint32_t sndhMemorySize, uint32_t hostReplayRate);
	const SongInfo&	GetSongInfo() const;
	uint32_t GetSubsongDurationSample(int subsongId) const;
	bool InitSubSong(int subSongId, bool predictibleYm2149State);
	void AudioRender(int16_t* buffer, uint32_t sampleCount);
	void AudioRenderWithVisualInfos(int16_t* buffer, uint32_t sampleCount, uint32_t* pVisualSamples);
	void MuteVoices(uint32_t muteVoiceMask) { m_atariMachine.MuteVoices(muteVoiceMask); }
	uint8_t GetYmRegister(unsigned reg) const { return m_atariMachine.GetYmRegister(reg); }
	void WriteYmRegister(unsigned reg, uint8_t value) { m_atariMachine.WriteYmRegister(reg, value); }
	bool IsReplayValid() const { return m_subsongInit; }

private:
	static	const	uint32_t	SNDH_UPLOAD_ADDR = 0x10002;		// some SNDH can't play below (ie SynthDream2) Also some driver crash if loaded at 64KiB bound ( metal planet by Floopy at 1:44 )

    // Private constructors prevent direct instantiation
    SndhRenderer();
    ~SndhRenderer();
    SndhRenderer(const SndhRenderer&) = delete;            // Prevent copy construction
    SndhRenderer& operator=(const SndhRenderer&) = delete; // Prevent copy assignment

	bool	Load(const void* rawSndhFile, uint32_t sndhFileSize, uint32_t hostReplayRate);
	void		AudioRenderInternal(int16_t* buffer, uint32_t count, uint32_t* pSampleViewInfo);

	AtariMachine m_atariMachine;
};

